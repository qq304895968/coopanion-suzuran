# 验证范围

## 可重复 CPU 测试

运行 `python -m pip install -r requirements-test.txt` 后执行 `npm test`。无需真实音频、模型、GPU 或网络；所有 fixture 在 `_tmp/` 中生成。

| 测试 | 验证内容 |
| --- | --- |
| smoke | 19 个工具、Cordis 定义与渲染契约 |
| config | 未创建路径、显式错误路径、环境变量、本机配置优先级、PATH 命令 |
| execution | 不存在的解释器启动失败、日志落盘 |
| ks | 合成 CP932 KAG3 剧本、音效/术语过滤、内嵌封包与伪签名拒绝 |
| parser | 合成 JSON → 数据集转码 → QC、单角色输入、留尾契约（尾部静音中位 ≈160ms、满电平样本判切断、`--trim-tail` 复现旧行为） |
| duration | 实际编码 OGG 与 WAV 的帧数、单/多角色、损坏文件、已解包输入的 acquire |
| register | 合成 checkpoint + 配置、可发现性、拒绝覆盖、缺配置不落盘 |
| package | npm 包的必要文件、排除素材/权重/个人配置 |

CI 配置为 Windows/Linux、Node 20、Python 3.10。CPU 测试通过不证明 GPU 训练、全部游戏解包或主观音质通过。

## 外部环境测试

- `node test/live.mjs`：读取 sources、doctor、overview。需先配置真实工程，缺依赖会返回非零。
- `node test/acquire.mjs`：联网下载上游测试样本、查询工具并按环境执行解包；可能下载内容到临时工作区，非默认测试。
- `node test/toolchain.mjs`：安装/检查外部工具；会访问网络或缓存，非默认测试。
- `node test/e2e.mjs`：真实预处理、20 步 GPU 训练、推理与注册。会操作外部 DDSP 数据与缓存目录，必须使用独立可清理的工程；维护发布时没有执行此项。

## 本机演示证据（2026-10-19）

既有演示记录显示：《千恋＊万花》体验版解包产出 7517 个文件，10 个角色目录中芳乃有 633 条音频。逐文件 `frames / sample rate` 汇总约 **37.1839 分钟**；旧按压缩字节数估算的时长不准确。

该轮**没有重新训练**。它读取已有 `model_20000.pt`，注册后模型与配置 SHA-256 与来源一致，原翻唱插件找到了本次注册文件并完成翻唱调用。用户仅明确认可一个等响度 8 秒干声 AB 的音色变化明显；不能扩大成整曲、混音、商业音质或所有试听均验收。

历史 QC 记录 358 段 / 24.8 分钟，无法证明该 checkpoint 实际使用了全部这些片段。当前训练目录与历史目录不同，不能据此重建训练数据来源。

原始报告含个人路径与素材引用，仅留在本机，不提交。Git 源码树不含演示游戏包、解包素材、训练语音、歌曲、参考音频、模型或视频文件。后续按用户明确要求，芳乃 20000 步检查点与配套配置单独上传为 [Release 附件](https://github.com/InariNGT-Ofiicial/dsh-train-pipeline/releases/tag/voice-yoshino-20000)，不包含训练素材。
